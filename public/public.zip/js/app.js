// AOS
document.addEventListener('DOMContentLoaded', function () {
    // Initialize AOS on page load
    AOS.init({
        duration: 1000,
        mirror: true,
    });
});